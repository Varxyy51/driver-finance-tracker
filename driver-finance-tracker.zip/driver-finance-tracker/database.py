import sqlite3
import pandas as pd

DB_NAME = "finance.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS transaksi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tanggal TEXT NOT NULL,
            kategori TEXT NOT NULL,
            jenis TEXT NOT NULL,
            nominal INTEGER NOT NULL,
            catatan TEXT
        )
    ''')
    conn.commit()
    conn.close()

def tambah_transaksi(tanggal, kategori, jenis, nominal, catatan):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        INSERT INTO transaksi (tanggal, kategori, jenis, nominal, catatan)
        VALUES (?, ?, ?, ?, ?)
    ''', (tanggal, kategori, jenis, nominal, catatan))
    conn.commit()
    conn.close()

def ambil_semua_transaksi():
    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT * FROM transaksi ORDER BY tanggal DESC, id DESC", conn)
    conn.close()
    return df

def hapus_transaksi(id_transaksi):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM transaksi WHERE id = ?", (id_transaksi,))
    conn.commit()
    conn.close()