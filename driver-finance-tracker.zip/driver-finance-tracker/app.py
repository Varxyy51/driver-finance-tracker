import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import date
from database import init_db, tambah_transaksi, ambil_semua_transaksi, hapus_transaksi

# Inisialisasi Database
init_db()

st.set_page_config(page_title="Driver Finance Tracker", page_icon="🛵", layout="wide")

st.title("🛵 Driver Finance & Order Tracker")
st.markdown("Aplikasi pencatat pemasukan harian, pengeluaran operasional (bensin/servis), dan evaluasi profit bersih.")

# Sidebar: Input Transaksi & Pengaturan Target
with st.sidebar:
    st.header("🎯 Target Harian")
    target_harian = st.number_input("Target Profit Bersih (Rp)", min_value=50000, value=150000, step=10000)
    
    st.divider()
    st.header("➕ Catat Transaksi Baru")
    with st.form("form_transaksi", clear_on_submit=True):
        tgl = st.date_input("Tanggal", value=date.today())
        jenis = st.selectbox("Jenis Transaksi", ["Pemasukan", "Pengeluaran"])
        
        if jenis == "Pemasukan":
            kategori = st.selectbox("Kategori", ["Tarif Orderan", "Tips Pelanggan", "Bonus Insentif"])
        else:
            kategori = st.selectbox("Kategori", ["Bensin / BBM", "Ganti Oli & Servis", "Paket Data / Kuota", "Makan & Minum", "Parkir / Lainnya"])
            
        nominal = st.number_input("Nominal (Rp)", min_value=1000, step=1000)
        catatan = st.text_input("Catatan (Opsional)", placeholder="Contoh: 12 trip siang - malam")
        
        submitted = st.form_submit_button("Simpan Transaksi", use_container_width=True)
        if submitted:
            tambah_transaksi(str(tgl), kategori, jenis, nominal, catatan)
            st.success("Data berhasil disimpan!")
            st.rerun()

# Ambil Data dari Database
df = ambil_semua_transaksi()

if df.empty:
    st.info("Belum ada data transaksi. Silakan input pemasukan atau pengeluaran pertama lewat menu di sebelah kiri.")
else:
    # Perhitungan Ringkasan
    total_masuk = df[df["jenis"] == "Pemasukan"]["nominal"].sum()
    total_keluar = df[df["jenis"] == "Pengeluaran"]["nominal"].sum()
    profit_bersih = total_masuk - total_keluar

    # Ringkasan Hari Ini
    hari_ini = str(date.today())
    df_today = df[df["tanggal"] == hari_ini]
    profit_today = (
        df_today[df_today["jenis"] == "Pemasukan"]["nominal"].sum()
        - df_today[df_today["jenis"] == "Pengeluaran"]["nominal"].sum()
    )

    # Tampilkan Metrik Utama
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Pemasukan", f"Rp {total_masuk:,.0f}")
    col2.metric("Total Pengeluaran", f"Rp {total_keluar:,.0f}")
    col3.metric("Profit Bersih Keseluruhan", f"Rp {profit_bersih:,.0f}")
    col4.metric("Profit Hari Ini", f"Rp {profit_today:,.0f}", delta=f"Target: Rp {target_harian:,.0f}")

    # Progress Bar Target Harian
    progress = min(max(profit_today / target_harian, 0.0), 1.0)
    st.write(f"**Pencapaian Target Hari Ini ({progress*100:.1f}%):**")
    st.progress(progress)

    st.divider()

    # Grafik Analitik
    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        st.subheader("📊 Tren Pemasukan vs Pengeluaran Harian")
        df_harian = df.groupby(["tanggal", "jenis"])["nominal"].sum().reset_index()
        fig_bar = px.bar(
            df_harian,
            x="tanggal",
            y="nominal",
            color="jenis",
            barmode="group",
            color_discrete_map={"Pemasukan": "#2ecc71", "Pengeluaran": "#e74c3c"},
            labels={"nominal": "Nominal (Rp)", "tanggal": "Tanggal", "jenis": "Jenis"}
        )
        st.plotly_chart(fig_bar, use_container_width=True)

    with col_chart2:
        st.subheader("🍩 Komposisi Pengeluaran Operasional")
        df_keluar = df[df["jenis"] == "Pengeluaran"]
        if not df_keluar.empty:
            fig_pie = px.pie(
                df_keluar,
                values="nominal",
                names="kategori",
                hole=0.4
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        else:
            st.write("Belum ada data pengeluaran untuk ditampilkan.")

    st.divider()

    # Tabel Riwayat & Fitur Hapus
    st.subheader("📋 Riwayat Transaksi")
    st.dataframe(df, use_container_width=True, hide_index=True)

    with st.expander("🗑️ Hapus Data Transaksi"):
        id_hapus = st.number_input("Masukkan ID Transaksi yang ingin dihapus", min_value=1, step=1)
        if st.button("Hapus Permanen"):
            hapus_transaksi(id_hapus)
            st.warning(f"Transaksi ID {id_hapus} telah dihapus.")
            st.rerun()